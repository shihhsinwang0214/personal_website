---
slug: "dma-w4-4-fm-vs-diffusion"
lang: "en"
title: "W4.4 Flow Matching 與 Diffusion：同與異"
category: "courses"
group: "Week 4 · Flow Matching"
status: "missing"
updated: 2026-09-04
summary: "English translation in progress; content-agent task."
demos: []
references: []
---

# Content Coming Soon

The content for this section is currently being prepared.

Please check back later for updates.
