---
slug: "dma-w3-4-reverse-process"
lang: "en"
title: "W3.4 反向：DDPM、DDIM 與 SDE/ODE"
category: "courses"
group: "Week 3 · Diffusion Models"
status: "missing"
updated: 2026-09-04
summary: "English translation in progress; content-agent task."
demos: []
references: []
---

# Content Coming Soon

The content for this section is currently being prepared.

Please check back later for updates.
