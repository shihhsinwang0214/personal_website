---
slug: "dma-w4-2-conditional-flow-matching"
lang: "en"
title: "W4.2 條件到邊際：Conditional Flow Matching"
category: "courses"
group: "Week 4 · Flow Matching"
status: "missing"
updated: 2026-09-04
summary: "English translation in progress; content-agent task."
demos: []
references: []
---

# Content Coming Soon

The content for this section is currently being prepared.

Please check back later for updates.
