---
slug: "flow-matching-flow-ode"
lang: "zh"
title: "從沙堆到沙堡：理解 Flow Matching 背後的 Flow ODE"
category: "research-areas"
group: "Flow Matching"
status: "available"
updated: 2026-04-01
summary: "從沙堆到沙堡：理解 Flow Matching 背後的 Flow ODE"
demos:
  - "notes/research_areas/flow-matching/story-sim-zh.html"
  - "notes/research_areas/flow-matching/story-velocity-zh.html"
  - "notes/research_areas/flow-matching/story-truncation-error-zh.html"
references: []
---
# 從沙堆到沙堡：理解 Flow Matching 背後的 Flow ODE

## 本章將會介紹

* **Flow Matching 的直覺理解**：從「隨機沙堆」到「精緻沙堡」
* **Flow Matching 背後的數學模型**：Flow ODE（一個連續時間微分方程）

---

## 引言 

在這個充斥著各種 AI 工具的時代，我們早已習慣輕輕點擊，就能看見栩栩如生的圖像憑空出現 。但剝開這層「魔法」的外衣，身為科學研究者的我們必須問一個更本質的問題：

 **讓一個數學模型「創造」出有結構的真實數據，究竟是如何做到的？**

在接下來的內容中，我們將探討一種強大且直觀的生成模型框架：**Flow Matching**。

為了幫助大家跨越抽象理論的門檻，我們不從冰冷的公式出發，而是先進行一場思想實驗 。我們將使用一個核心比喻：

👉 **從「隨機沙堆」到「精緻沙堡」** 這不僅是一個生動的比喻，更對應了 Flow Matching 背後的數學設計哲學。最終，我們將回到核心：如何用嚴謹的數學語言，精確描述並控制這個連續的生成過程。


## 什麼是「生成」？

在這個世界中，存在著各種真實數據，例如影像、音訊或文字。

現在，我們希望能「創造出新的內容」。
但這個創造，並不是憑空產生，而是建立在一個重要前提上：

👉 我們**有參考的資料**。

也就是說，我們會從既有的數據中觀察、學習其中的規律，
再依據這些規律，產生「新的、但合理的」內容，
而不是單純複製過去看過的資料。

那麼問題來了：

👉 我們要怎麼讓一個模型，
學會這些規律，並真正做到「生成」？

---

### 人類是怎麼創作的？

其實，人類在創作時，很少是「憑空瞬間完成」一個作品。

更多時候，我們會從一個很粗糙、甚至是混亂的起點開始，例如：
- 一張空白的畫布  
- 一塊未雕刻的大理石  
- 或是一堆毫無形狀的沙子  

然後透過一個「逐步修改」的過程，不斷調整、精煉，最後變成有意義的作品。

---

### 思想實驗：從沙堆到沙堡

想像你在海灘上，面前有一堆隨機堆積的沙子。

你的目標，是把這堆沙子變成一座精緻的沙堡。

你不會一次完成，而是會：
- 一次移動一部分沙子  
- 一點一點改變整體形狀  
- 慢慢讓結構變得清晰、有組織  

最終，原本混亂的沙堆，就變成了一個有結構的沙堡。

---

### 把這件事轉成「生成模型」

如果我們把「每一顆沙子的位置」想像成「資料點」，

那麼可以這樣理解：

- 真實數據（real data）的分布＝「已經完成的沙堡」  
- 隨機輸入（noise）的分布＝「一開始的沙堆」  

那麼問題就變成：

👉 我們能不能設計一個模型，
讓這些原本隨機的點，

一步一步被移動，
最後變成有意義的資料？

💡 數學補充：

在實際情況中，我們的資料通常位於一個高維空間中，記作：

$$
x \in \mathbb{R}^n
$$

也就是說，每一個資料點（或「一顆沙子」）其實是由 $n$ 個數值所組成的向量。

👉 例如：
- 一張影像可以看作高維向量（每個 pixel 是一個維度）  
- 一段聲音或文字 embedding 也都位於高維空間中  

因此，前面所描述的「搬運過程」，實際上是發生在高維空間中的點的移動。

---

為了幫助理解，我們通常會用 2 維或 3 維的例子來視覺化這個過程，  
但 Flow Matching 的方法本身並不依賴低維結構，  
可以直接應用在高維資料上。

---

### 但關鍵問題在這裡

這個「移動的過程」**不是只看最終的沙堡（target）就能決定怎麼走**，  
也不是只看起點的沙堆（source）。

👉 真正重要的是：  
我們需要同時理解「起點們長什麼樣」，以及「終點們長什麼樣」，  
然後在兩者之間**建立一條合理的變化路徑**。

換句話說：

- 我們不是只在學「最後長什麼樣」
- 而是在學「如果從 A 變到 B，中間應該怎麼動」

---

## 這條路徑其實是「隨時間發生的」

如果我們仔細想像這個搬運過程：

它其實不是一步完成的，而是**連續發生的**。

也就是說：

- 在 $t = 0$ 時，是混亂的沙堆  
- 在 $0 < t < 1$ 的每一刻，沙子都在移動  
- 在 $t = 1$ 時，變成完整的沙堡  

👉 換句話說，這條「軌跡」其實是一個隨時間演化的過程。

我們可以用一個函數來描述每一顆沙子在 t 時刻的位置：

👉 $x(t)$

👇 動手探索：請拖曳下方的時間軸，親眼觀察 $x(t)$，觀察這些代表噪聲的「沙堆」，是如何一步步被搬運並聚集成有結構的「沙堡」！


<iframe loading="lazy" src="/personal_website/notes/research_areas/flow-matching/story-sim-zh.html" class="demo-frame" style="height: 1080px; width: 100%; border: none;"></iframe>


---

## Flow ODE 的觀點

有了 $x(t)$ 之後，我們可以進一步問：

👉 在每一個時間點，這顆沙子是「怎麼移動的」？

也就是：

👉 它的「移動方向」是什麼？

這個瞬時移動方向，我們稱為：

👉 velocity field（速度場） $v(x, t)$

---

因此，我們可以用一個微分方程來描述整個過程：

$$
\frac{dx}{dt} = v(x(t), t)
$$

👉 這個方程的意思是：  
在時間 $t$ 、軌跡走到位置 $x(t)$ ，點會依照 $v(x(t),t)$ 指定的方向移動。

這就是 **Flow ODE** ，也是 Flow Matching 背後的數學模型。

---

## 用 Flow ODE 來生成資料

如果我們從一個隨機初始點開始出發：

$$
x(0) \sim p_{\text{noise}}
$$


並讓它依照 Flow ODE 演化：

$$
\frac{dx}{dt} = v(x(t), t), \quad t \in [0,1]
$$

那麼在 $t = 1$ 時，我們就會得到生成的樣本：

$$
x(1) = x(0) + \int_0^1 v(x(t), t)\, dt
$$

👉 也就是說，我們從初始點 $x(0)$ 出發，  
👉 沿著 velocity field $v(x,t)$ 持續累積「位移」，  
👉 最終得到生成的樣本 $x(1)$。

  <iframe loading="lazy" src="/personal_website/notes/research_areas/flow-matching/story-velocity-zh.html" class="demo-frame" style="height: 1200px; width: 100%; border: none;"></iframe>


---

### 實際做法：數值離散化

在實際計算中，我們無法直接解這個連續積分，  
因此會將時間離散化：

$$
0 = t_0 < t_1 < \cdots < t_N = 1
$$

並使用數值方法來近似，例如使用 Euler discretization：

$$
x_{k+1} = x_k + \Delta t \cdot v(x_k, t_k)
$$

其中：

- $x_k \approx x(t_k)$  
- $\Delta t = t_{k+1} - t_k$

意思就是說，我們每一步只會「看一次方向」，然後沿著這個方向走一小段時間 $\Delta t$，  
接著再重新更新方向，而不是像理想積分那樣「每一瞬間都持續更新方向」。

---

💡 數學補充：

這種「用離散步驟去近似連續時間演化」的方法，本質上會產生誤差，通常被稱為：**truncation error**.


<iframe loading="lazy" src="/personal_website/notes/research_areas/flow-matching/story-truncation-error-zh.html" class="demo-frame" style="height: 960px; width: 100%; border: none;"></iframe>


---

👉 換句話說：

> Flow Matching 的生成，就是「沿著方向場，一步一步走出來的」

---

### 直覺理解

👉 一開始：點是隨機分散的（沙堆）  
👉 過程中：每一刻都依照 $v(x,t)$ 被推動  
👉 最後：點被「搬運」到有結構的位置（沙堡）  

---

### 重要觀察

👉 我們不需要「直接生成一個資料」  
👉 而是讓一個簡單的分佈（noise），  
👉 在一個連續的 flow 中被轉換成複雜的資料分佈  

---

👉 換句話說：

> Flow Matching 學到的不是「資料本身」  
> 而是一個「把 noise 變成 data 的過程」
> 他把點從代表 noise 的位置，變成代表有意義 data 的位置

## 最終總結

我們現在已經透過沙堆到沙堡的例子來介紹 Flow ODE，建立了 Flow Matching的生成觀點。

---

👉 接下來的關鍵問題是：

**這個 $v(x, t)$ 要怎麼決定？是怎麼學出來的？**

這會在下一篇揭曉！

---

## 參考文獻 (References)

1. Lipman, Yaron, Ricky TQ Chen, Heli Ben-Hamu, Maximilian Nickel, and Matt Le. "Flow Matching for Generative Modeling." ICLR 2023.

2. Liu, Xingchao, and Chengyue Gong. "Flow Straight and Fast: Learning to Generate and Transfer Data with Rectified Flow." ICLR 2023.
