---
slug: "dma-w3-5-lab"
label: "dma-lab-diffusion"
lang: "en"
title: "W3.5 實作：建立這一週的 Toy"
category: "courses"
group: "Week 3 · Diffusion Models"
status: "missing"
updated: 2026-09-04
summary: "English translation in progress; content-agent task."
demos: []
references: []
---

# Content Coming Soon

The content for this section is currently being prepared.

Please check back later for updates.
