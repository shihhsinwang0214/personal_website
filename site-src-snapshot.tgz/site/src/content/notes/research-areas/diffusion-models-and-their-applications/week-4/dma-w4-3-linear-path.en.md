---
slug: "dma-w4-3-linear-path"
label: "dma-linear-path"
lang: "en"
title: "W4.3 直線插值：條件直，邊際不直"
category: "courses"
group: "Week 4 · Flow Matching"
status: "missing"
updated: 2026-09-04
summary: "English translation in progress; content-agent task."
demos: []
references: []
---

# Content Coming Soon

The content for this section is currently being prepared.

Please check back later for updates.
