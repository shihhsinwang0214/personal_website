/**
 * noteRefs.ts — resolve stable cross-reference labels to the *current* slug, title and
 * position code ("W3.3", "M1.4") of a note.
 *
 * HARD RULE for course notes: never hard-code "W3.3" / a slug in prose. Give every note a
 * frontmatter `label` and reference it with <Ref to="label"/>, <Bridge to="label">,
 * `prereqs: [label, …]`. Week / part numbers are derived here at build time from the
 * note's `group` ("Week 3 · …" → W3, "M1 · …" → M1) and its position in `noteSlugList`,
 * so renumbering a week or reordering notes never breaks a link or a code.
 */
import { getCollection } from 'astro:content';
import type { Lang, NoteEntry } from './notes';
import { courseKeyForGroup, courseByKey, lectureByLabel, noteOrderIndex, noteRoute } from './notes';
import { withBase } from './url';

export interface ResolvedNoteRef {
  slug: string;
  label: string;
  lang: Lang;
  title: string;
  /** Title with a leading position code ("W3.3 ") stripped, if the author typed one. */
  shortTitle: string;
  /** Position code, e.g. "W3.3", "M1.4"; empty for notes outside a numbered group. */
  code: string;
  group: string;
  courseKey?: string;
  href: string;
  summary: string;
}

let indexPromise: Promise<Map<string, NoteEntry[]>> | null = null;

/** label|slug → entries (both languages). Built once per build. */
async function noteIndex(): Promise<Map<string, NoteEntry[]>> {
  if (!indexPromise) {
    indexPromise = getCollection('notes').then((notes) => {
      const map = new Map<string, NoteEntry[]>();
      const push = (key: string, note: NoteEntry) => {
        const list = map.get(key);
        if (list) list.push(note);
        else map.set(key, [note]);
      };
      for (const note of notes) {
        push(note.data.slug, note);
        if (note.data.label && note.data.label !== note.data.slug) push(note.data.label, note);
      }
      return map;
    });
  }
  return indexPromise;
}

const GROUP_CODE = /^(Week|Lecture|W|L|M)\s*(\d+)/i;

/** "Week 3 · Diffusion Models" → "W3"; "M1 · …" → "M1"; otherwise "". */
export function groupCode(group: string): string {
  const m = GROUP_CODE.exec(group);
  if (!m) return '';
  return `${m[1][0].toUpperCase()}${m[2]}`;
}

/** Position of a note inside its group (0-based, per `noteSlugList` order). */
async function positionInGroup(note: NoteEntry): Promise<number> {
  const all = await getCollection('notes');
  const siblings = all
    .filter((n) => n.data.group === note.data.group && n.data.lang === note.data.lang)
    .map((n) => n.data.slug)
    .filter((slug, i, arr) => arr.indexOf(slug) === i)
    .sort((a, b) => noteOrderIndex(a) - noteOrderIndex(b));
  return siblings.indexOf(note.data.slug);
}

export async function noteCode(note: NoteEntry): Promise<string> {
  const g = groupCode(note.data.group);
  if (!g) return '';
  const i = await positionInGroup(note);
  return i < 0 ? g : `${g}.${i}`;
}

function stripCode(title: string, code: string): string {
  if (!code) return title;
  const re = new RegExp(`^${code.replace('.', '\\.')}\\s*[·:：]?\\s*`);
  return title.replace(re, '');
}

/**
 * Resolve a label or slug. Prefers the requested language; falls back to the other
 * language's entry (the link still goes to the requested language route, where the
 * site renders its "translation missing" page).
 */
export async function resolveNoteRef(key: string, lang: Lang): Promise<ResolvedNoteRef | undefined> {
  const index = await noteIndex();
  const entries = index.get(key);
  if (!entries || entries.length === 0) return undefined;
  const note = entries.find((n) => n.data.lang === lang) ?? entries[0];
  const code = await noteCode(note);
  return {
    slug: note.data.slug,
    label: note.data.label ?? note.data.slug,
    lang,
    title: note.data.title,
    shortTitle: stripCode(note.data.title, code),
    code,
    group: note.data.group,
    courseKey: courseKeyForGroup(note.data.group),
    href: withBase(noteRoute(note.data.slug, lang)),
    summary: note.data.summary,
  };
}

export interface ResolvedWeekRef {
  code: string;
  group: string;
  courseTitle: string;
  href: string;
}

/** Resolve a lecture label ("dma-week-interpolants") to "W5" + a link to its first note. */
export async function resolveWeekRef(label: string, lang: Lang): Promise<ResolvedWeekRef | undefined> {
  const hit = lectureByLabel(label);
  if (!hit) return undefined;
  const all = await getCollection('notes');
  const first = all
    .filter((n) => n.data.group === hit.lecture.group && n.data.lang === lang)
    .sort((a, b) => noteOrderIndex(a.data.slug) - noteOrderIndex(b.data.slug))[0];
  return {
    code: groupCode(hit.lecture.group),
    group: hit.lecture.group,
    courseTitle: hit.course.title[lang],
    href: first ? withBase(noteRoute(first.data.slug, lang)) : withBase(lang === 'zh' ? 'zh/notes' : 'notes'),
  };
}

export interface UsedByGroup {
  courseKey: string;
  courseTitle: string;
  notes: ResolvedNoteRef[];
}

/** Every note whose `prereqs` names this note (by label or slug), grouped by course. */
export async function usedBy(slugOrLabel: string, lang: Lang): Promise<UsedByGroup[]> {
  const index = await noteIndex();
  const targets = new Set((index.get(slugOrLabel) ?? []).flatMap((n) => [n.data.slug, n.data.label ?? n.data.slug]));
  if (targets.size === 0) return [];
  const all = await getCollection('notes');
  const usesTarget = (n: NoteEntry) => n.data.prereqs.some((p) => targets.has(p));
  // Prefer the current language's entries; a note whose zh side declares prereqs but whose
  // en stub does not is still listed (declarations live on whichever side is authored).
  const users = [
    ...all.filter((n) => n.data.lang === lang && usesTarget(n)),
    ...all.filter((n) => n.data.lang !== lang && usesTarget(n)),
  ];
  const seen = new Set<string>();
  const groups = new Map<string, UsedByGroup>();
  for (const n of users) {
    if (seen.has(n.data.slug)) continue;
    seen.add(n.data.slug);
    const ref = await resolveNoteRef(n.data.slug, lang);
    if (!ref) continue;
    const courseKey = ref.courseKey ?? '__other';
    const course = courseKey === '__other' ? undefined : courseByKey(courseKey);
    const g = groups.get(courseKey) ?? {
      courseKey,
      courseTitle: course ? course.title[lang] : ref.group,
      notes: [],
    };
    g.notes.push(ref);
    groups.set(courseKey, g);
  }
  for (const g of groups.values()) {
    g.notes.sort((a, b) => noteOrderIndex(a.slug) - noteOrderIndex(b.slug));
  }
  return [...groups.values()];
}

/** Language of the page being rendered, from its URL. */
export function langFromUrl(url: URL): Lang {
  return /\/zh(\/|$)/.test(url.pathname) ? 'zh' : 'en';
}
